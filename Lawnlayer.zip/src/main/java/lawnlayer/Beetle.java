package lawnlayer;

import java.util.*;

public class Beetle extends Enemies {
    
    public Beetle(int x, int y){
        super (x, y);
    }

}
