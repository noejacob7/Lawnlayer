package lawnlayer;

import java.util.*;

public class Worm extends Enemies {
    
    public Worm(int x, int y){
        super(x, y);
    }
}
